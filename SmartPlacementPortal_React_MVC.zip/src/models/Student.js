class Student {
  constructor(name, registerNo, cgpa, skills) {
    this.name = name;
    this.registerNo = registerNo;
    this.cgpa = cgpa;
    this.skills = skills;
  }
}

export default Student;