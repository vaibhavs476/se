class Job {
  constructor(company, role, packageLPA, minCgpa, requiredSkill) {
    this.company = company;
    this.role = role;
    this.packageLPA = packageLPA;
    this.minCgpa = minCgpa;
    this.requiredSkill = requiredSkill;
  }
}

export default Job;