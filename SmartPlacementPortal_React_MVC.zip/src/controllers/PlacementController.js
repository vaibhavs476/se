import Student from "../models/Student";
import Job from "../models/Job";

class PlacementController {
  constructor() {
    this.student = new Student(
      "Bhuvanesh",
      "101",
      8.5,
      ["Java", "React", "SQL"]
    );

    this.jobs = [
      new Job("TCS", "Java Developer", 7.5, 7.0, "Java"),
      new Job("Infosys", "React Developer", 8.0, 7.5, "React"),
      new Job("Accenture", "Software Engineer", 6.5, 8.0, "SQL")
    ];
  }

  getStudent = () => {
    return this.student;
  };

  getEligibleJobs = () => {
    return this.jobs.filter(
      (job) =>
        this.student.cgpa >= job.minCgpa &&
        this.student.skills.includes(job.requiredSkill)
    );
  };

  applyForJob = (job) => {
    alert(
      `Application submitted for ${job.role} at ${job.company}`
    );
  };
}

export default PlacementController;