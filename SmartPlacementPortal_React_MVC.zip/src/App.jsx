import React from "react";
import PlacementController from "./controllers/PlacementController";
import PlacementView from "./views/PlacementView";

function App() {
  const controller = new PlacementController();

  const student = controller.getStudent();
  const jobs = controller.getEligibleJobs();

  return (
    <PlacementView
      student={student}
      jobs={jobs}
      onApply={controller.applyForJob}
    />
  );
}

export default App;