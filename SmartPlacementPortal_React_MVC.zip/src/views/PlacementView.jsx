import React from "react";

function PlacementView({ student, jobs, onApply }) {
  return (
    <div className="container">
      <header>
        <h1>Smart College Placement Portal</h1>
        <p>Student Placement Dashboard</p>
      </header>

      <section className="student-card">
        <h2>Student Profile</h2>
        <p><strong>Name:</strong> {student.name}</p>
        <p><strong>Register Number:</strong> {student.registerNo}</p>
        <p><strong>CGPA:</strong> {student.cgpa}</p>
        <p>
          <strong>Skills:</strong> {student.skills.join(", ")}
        </p>
      </section>

      <section>
        <h2>Eligible Job Opportunities</h2>

        {jobs.length === 0 ? (
          <p>No eligible jobs available.</p>
        ) : (
          <div className="job-list">
            {jobs.map((job, index) => (
              <div className="job-card" key={index}>
                <h3>{job.company}</h3>
                <p><strong>Role:</strong> {job.role}</p>
                <p><strong>Package:</strong> {job.packageLPA} LPA</p>
                <p><strong>Minimum CGPA:</strong> {job.minCgpa}</p>
                <p><strong>Required Skill:</strong> {job.requiredSkill}</p>

                <button onClick={() => onApply(job)}>
                  Apply Now
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default PlacementView;