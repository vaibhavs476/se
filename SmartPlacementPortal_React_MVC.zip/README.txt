SMART COLLEGE PLACEMENT PORTAL
REACT MVC PROJECT

This project demonstrates the MVC design pattern using React.

MVC STRUCTURE

Model
- Student.js
- Job.js

Controller
- PlacementController.js

View
- PlacementView.jsx

Application
- App.jsx

TECHNOLOGY

React
Vite
JavaScript
CSS

HOW TO RUN

1. Install Node.js.
2. Extract this ZIP file.
3. Open the project folder in VS Code.
4. Open the terminal.
5. Run:

npm install

6. Then run:

npm run dev

7. Open the localhost URL shown in the terminal.

MVC WORKFLOW

Student/Job Model
       |
       v
Placement Controller
       |
       v
Placement View
       |
       v
React Application

The Model stores student and job data.
The Controller contains placement logic such as eligibility checking.
The View displays the student profile and eligible jobs.
React components connect the MVC parts together.
